import SwiftUI

extension Font {
    static let SingleDay : Font = .custom("SingleDay-Regular", size: 25)
}
